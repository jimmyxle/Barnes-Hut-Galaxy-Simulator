#pragma once
#include <cuda.h>
#include <cuda_runtime.h>
#include <device_launch_parameters.h>

using namespace std;
__device__ const int blockSize = 640;
__shared__ float3 sharedPoints[blockSize];

__global__ void FindClosestGPU(float3* points, int* indices, int count)
{
	if (count <= 1) return;
	int idx = threadIdx.x + blockIdx.x * blockDim.x;

	if (idx < count)
	{
		float3 thisPoint = points[idx];
		float smallestSoFar = 3.40282e38f;

		for (int i = 0; i < count; i++)
		{
			if (i == idx) continue; //if same pt, return
			float dist = (thisPoint.x - points[i].x)*(thisPoint.x - points[i].x);
			dist += (thisPoint.y - points[i].y)*(thisPoint.y - points[i].y);
			dist += (thisPoint.z - points[i].z)*(thisPoint.z - points[i].z);

			if (dist < smallestSoFar)
			{
				smallestSoFar = dist;
				indices[idx] = i;
			}
		}

	}

}

__global__ void FindClosestGPU2(float3* points, int* indices, int count)
{
	if (count <= 1) return;
	int idx = threadIdx.x + blockIdx.x*blockDim.x;
	int indexOfClosest = -1;
	float3 thisPoint;
	float distanceToClosest = 3.40282e34f;
	if (idx < count) thisPoint = points[idx];
	for (int currentBlockOfPoints = 0; currentBlockOfPoints < gridDim.x; currentBlockOfPoints++)
	{
		if (threadIdx.x + currentBlockOfPoints * blockSize < count)
		{
			sharedPoints[threadIdx.x] = points[threadIdx.x + currentBlockOfPoints*blockSize];

		}
		__syncthreads();
		if (idx < count)
		{
			float* ptr = &sharedPoints[0].x;
			for (int i = 0; i < blockSize; i++)
			{
				float dist = (thisPoint.x - ptr[0])*(thisPoint.x - ptr[0]) +
					(thisPoint.y - ptr[1])*(thisPoint.y - ptr[1]) +
					(thisPoint.z - ptr[2])*(thisPoint.z - ptr[2]);
				ptr += 3;
				if ((dist < distanceToClosest) &&
					(i + currentBlockOfPoints)*blockSize < count &&
					(i + currentBlockOfPoints * blockSize != idx))
					{
					distanceToClosest = dist;
					indexOfClosest = i + currentBlockOfPoints*blockSize;
					}
			}
		}
		__syncthreads();
	}

}
