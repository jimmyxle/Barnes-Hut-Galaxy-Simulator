#define CL_USE_DEPRECATED_OPENCL_2_0_APIS
#include <CL/cl.hpp>
//#include <vector>

int main(void)
{
	std::vector<cl::Platform> platforms;
	cl::Platform::get (&platforms);

	_ASSERT(platforms.size() > 0 );

	auto platform = platforms.front();
	std::vector<cl::Device> devices;

	platform.getDevices( CL_DEVICE_TYPE_ALL, &devices );
	_ASSERT(devices.size() > 0);

	auto device = devices.front();
	auto vendor = device.getInfo<CL_DEVICE_VENDOR>();
	auto version = device.getInfo<CL_DEVICE_VERSION>();

	device = devices.back();
	vendor = device.getInfo<CL_DEVICE_VENDOR>();
	version = device.getInfo<CL_DEVICE_VERSION>();

	platform = platforms[1];
	platform.getDevices(CL_DEVICE_TYPE_ALL, &devices);
	_ASSERT(devices.size() > 0);

	device = devices.front();
	vendor = device.getInfo<CL_DEVICE_VENDOR>();
	version = device.getInfo<CL_DEVICE_VERSION>();

	return 0;
}