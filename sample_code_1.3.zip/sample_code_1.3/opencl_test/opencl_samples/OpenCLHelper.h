#pragma once
#define CL_USE_DEPRECATED_OPENCL_2_0_APIS


#include <CL/cl.hpp>
#include <fstream>
cl::Program CreateProgram(const std::string& file);
