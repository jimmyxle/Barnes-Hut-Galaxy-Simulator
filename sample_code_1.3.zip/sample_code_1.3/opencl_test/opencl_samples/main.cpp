#include "OpenCLHelper.h"
#include <iostream>
#include <conio.h>
#include <numeric>


int main(void)
{
	auto program = CreateProgram("NumericalReduction.cl");
	auto context = program.getInfo<CL_PROGRAM_CONTEXT>();
	auto devices = context.getInfo < CL_CONTEXT_DEVICES>();
	_ASSERT(devices.size() > 0);
	auto& device = devices.front();

	std::vector<cl_int> vec(2048);
	int count = 0;
	for (int i = 0; i < vec.size(); i++)
	{
		vec[i] = i;
		count += i;
	}
	cl::Kernel kernel(program, "NumericalReduction");
	cl_int err = 0;
	auto workGroupSize = kernel.getWorkGroupInfo<CL_KERNEL_WORK_GROUP_SIZE>(device, &err);

	auto numWorkGroups = vec.size() / workGroupSize;

	//device read this | host do nothing | host copy
	cl::Buffer buf(context, CL_MEM_READ_ONLY | CL_MEM_HOST_NO_ACCESS | CL_MEM_COPY_HOST_PTR, sizeof(int)*vec.size(), vec.data());

	cl::Buffer outBuf(context, CL_MEM_WRITE_ONLY | CL_MEM_HOST_READ_ONLY, sizeof(int)*numWorkGroups);

	kernel.setArg(0, buf);
	kernel.setArg(1, sizeof(int)*workGroupSize, nullptr);
	kernel.setArg(2, outBuf);

	std::vector<int> outVec(numWorkGroups);

	cl::CommandQueue queue(context, device);
	queue.enqueueNDRangeKernel(kernel, cl::NullRange, cl::NDRange(vec.size()), cl::NDRange(workGroupSize));

	queue.enqueueReadBuffer(outBuf, CL_TRUE, 0, sizeof(int)*outVec.size(), outVec.data());


	auto sum = std::accumulate(outVec.cbegin(), outVec.cend(), 0);


	/* process array example */
	/*
	auto program = CreateProgram("ProcessArray.cl");
	auto context = program.getInfo<CL_PROGRAM_CONTEXT>();
	auto devices = context.getInfo < CL_CONTEXT_DEVICES>();
	_ASSERT(devices.size() > 0);
	auto& device = devices.front();


	std::vector<int> vec(1024);
//	std::fill(vec.begin(), vec.end(), 1);
	//can check cl error codes.
	cl_int err = 0;

	cl::Buffer inBuf(context, CL_MEM_READ_ONLY | CL_MEM_HOST_NO_ACCESS | CL_MEM_COPY_HOST_PTR, sizeof(int)*vec.size(), vec.data(), &err);
	cl::Buffer outBuf(context, CL_MEM_WRITE_ONLY | CL_MEM_HOST_READ_ONLY, sizeof(int)*vec.size(), nullptr, &err);
	cl::Kernel kernel(program, "ProcessArray");
	err = kernel.setArg(0, inBuf);
	err = kernel.setArg(1, outBuf);

	cl::CommandQueue queue(context, device);
	
	err = queue.enqueueFillBuffer(inBuf, 3, sizeof(int) * 10, sizeof(int)*(vec.size() - 10));

	 err = queue.enqueueNDRangeKernel(kernel, cl::NullRange, cl::NDRange(vec.size()));
	err = queue.enqueueReadBuffer(outBuf, CL_FALSE, 0, sizeof(int)*vec.size(), vec.data());
	
	cl::finish(); // make srue to finish every command
	*/

	
	/* READ FROM THE FILE EXAMPLE*/
	/*
	auto program = CreateProgram("HelloWorld.cl");
	auto context = program.getInfo<CL_PROGRAM_CONTEXT>();
	auto devices = context.getInfo < CL_CONTEXT_DEVICES>();
	_ASSERT( devices.size() > 0 );
	auto& device = devices.front();
	//buffer store string
	char buf[16];
	//context, flags, size
	//write into buf, read from file, think about diff mem
	cl::Buffer memBuf(context, CL_MEM_WRITE_ONLY | CL_MEM_HOST_READ_ONLY, sizeof(buf));
	cl::Kernel kernel(program, "Hello");
//	//index value, actual param
	kernel.setArg(0, memBuf);

	//send commands to device
	cl::CommandQueue queue(context, device);

	queue.enqueueTask(kernel);
	//read from global, hold the buffeer?, offset, size of buffer, actual bffer
	queue.enqueueReadBuffer(memBuf, CL_TRUE, 0, sizeof(buf), buf);

	std::cout << buf;
	*/

	_getch();
	
	return 0;
}