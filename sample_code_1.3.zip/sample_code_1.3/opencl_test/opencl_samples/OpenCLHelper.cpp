#include "OpenCLHelper.h"


cl::Program CreateProgram(const std::string& file)
{
	std::vector<cl::Platform> platforms;
	cl::Platform::get(&platforms);

	auto platform = platforms[1];
	std::vector<cl::Device> devices;
	platform.getDevices(CL_DEVICE_TYPE_GPU, &devices);
	//keep as cpu so its not so bad when you fuck up the algorithm. When confident, change to gpu
	auto device = devices.front();
	auto vendor = device.getInfo<CL_DEVICE_VENDOR>();

	std::ifstream fp(file);
	std::string src(std::istreambuf_iterator<char>(fp), (std::istreambuf_iterator<char>()));
	cl::Program::Sources sources(1, std::make_pair(src.c_str(), src.length() + 1));
	cl::Context context(device);
	cl::Program program(context, sources);

	program.build("-cl-std=CL1.2");

	return program;

}